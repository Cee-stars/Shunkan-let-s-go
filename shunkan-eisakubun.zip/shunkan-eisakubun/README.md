# 瞬間英作文 ⚡

日本語 → 英語を、見た瞬間に口に出すためのトレーナー。iPhone / MacBook 両対応の PWA です。

## ファイル

```
index.html               アプリ本体（これ1つで動きます）
manifest.json            ホーム画面／Dock に入れるための設定
sw.js                    オフライン用
icon-192.png             アイコン
icon-512.png             アイコン
icon-maskable-512.png    Android/Chrome 用（角丸マスク対応）
apple-touch-icon.png     iPhone ホーム画面用（180px）
```

## GitHub Pages に置く

1. GitHub で新しいリポジトリを作る（例：`shunkan`）。Public にする。
2. 上のファイルを**全部そのまま**アップロード（フォルダを作らず、リポジトリ直下に置く）。
3. Settings → Pages → Source を **Deploy from a branch**、Branch を **main / (root)** にして Save。
4. 1〜2分待つと `https://ユーザー名.github.io/shunkan/` が開く。

## ホーム画面／Dock に入れる

- **iPhone（Safari）**：ページを開く → 共有ボタン → 「ホーム画面に追加」
- **Mac（Safari）**：ファイル → 「Dock に追加」
- **Mac（Chrome）**：アドレスバー右のインストールアイコン → 「インストール」

アドレスバーが消えて、アプリとして起動します。オフラインでも動きます。

## データについて

データはその端末の中（ブラウザのローカル保存）にだけ残ります。iPhone と Mac の間では自動同期しません。
移すときは メニュー → **バックアップを書き出す** で JSON を保存し、もう一方の端末で **読み込む**。

Safari は「長期間使わないサイトのデータを消す」ことがあるので、たまに書き出しておくと安心です。

## ショートカット（Mac）

| キー | 動作 |
|---|---|
| ⌘1 | 選択した部分を赤（主語）に |
| ⌘2 | 選択した部分を青（動詞）に |
| ⌘3 | 黒に戻す |
| ⌘Enter | 保存 |
| Space | 練習中：答えを見る |
| → / ← | 練習中：言えた／もう一回 |
